# Analysis Framework - Eight-Part Criminal Disclosure Analysis

Every criminal disclosure analysis follows this eight-part structure. Adapt depth
and emphasis based on case complexity and available disclosure.

---

## Part 1: Charge Analysis

For each charge laid:

- **Offence section**: Identify the statutory provision alleged
- **Elements**: List each legal element the Crown must prove
- **Maximum penalty**: Note the statutory maximum
- **Evidential sufficiency**: Initial assessment of whether the disclosed
evidence, taken at its highest, could support a conviction
- **Defences available**: Identify any complete or partial defences suggested
by the disclosed material (self-defence, alibi, consent, mental impairment,
automatism, etc.)
- **Sentencing range indication**: If convicted, the likely starting point
and available discounts

**Expert integration**: Each expert reviews independently. Expert 1 focuses on
procedural attack points. Expert 2 assesses evidential sufficiency. Expert 3
examines whether charges properly reflect the disclosed conduct.

---

## Part 2: Summary of Facts Review

Detailed examination of the Summary of Facts (SoF):

- **Narrative accuracy**: Does the SoF fairly reflect the disclosed evidence?
- **Procedural errors**: Any non-compliance with Criminal Procedure Act 2011
requirements for charging documents
- **Omissions**: Material facts favourable to the defence omitted from the SoF
- **Timeline analysis**: Construct timeline from SoF, compare against:
  - Witness statements (note inconsistencies)
  - Police notebook entries (note discrepancies)
  - CCTV/metadata timestamps if available
  - Medical/forensic report dates
- **Hearsay and admissibility**: Identify inadmissible assertions in the SoF
- **Inference chains**: Identify where the SoF draws inferences beyond the
evidence

---

## Part 3: Police Conduct Assessment

Comprehensive review of police conduct throughout the investigation:

### 3A - Bill of Rights Act 1990 (NZBORA) Compliance

Check each protected right against the disclosed conduct:
- **s 21** - Unreasonable search/seizure: Was the search lawful? Warrant valid?
Scope exceeded? Warrantless search justified under S&S Act 2012?
- **s 22** - Liberty of the person: Was arrest necessary and lawful?
- **s 23(1)** - Humane treatment during arrest/detention
- **s 23(2)** - Right to consult lawyer without delay
- **s 23(3)** - Right to have lawyer present during interview
- **s 23(4)** - Right to remain silent (adverse inference risks under
Evidence Act 2006)
- **s 23(5)** - Right to be informed of reason for arrest and rights
- **s 24** - Minimum standards of criminal procedure (fair trial)
- **s 25** - Rights of accused persons (presumption of innocence,
prompt charge, disclosure, interpreter)
- **s 27** - Right to justice (natural justice principles)

For each potential breach: identify the right, describe the conduct,
assess whether breach is established, and recommend remedy (exclusion of
evidence, stay of proceedings, or sentencing credit).

### 3B - Procedural Breaches

- Proper laying of charges and informing the accused
- Disclosure obligations under Criminal Disclosure Act 2008
- Interview procedures (record of interview quality, caution adequacy,
 voluntariness)
- Chain of custody for exhibits
- Search warrant validity (issuing authority, particularity, execution,
 return)
- Identification procedures (compliance with best practice)
- Custody time limits

### 3C - Statement Inconsistencies

Compare across all disclosed statements:
- Complainant statements (v1, v2, etc.)
- Witness statements
- Police notebook entries
- Record of interview with accused
- 111/emergency calls
- Pre-trial briefings to counsel

Flag: direct contradictions, material omissions between versions, newly
introduced details, changes in chronology, and credibility implications.

### 3D - Warrant and Search Power Analysis

- Is the warrant valid on its face?
- Was the issuing officer authorised?
- Does the warrant particularise the place/things to be searched?
- Was execution within the authorised timeframe?
- Was the scope of the search exceeded?
- If warrantless: was the statutory power available? Was the threshold met?
- Digital device searches: special considerations under s 130 Search and
Surveillance Act 2012

---

## Part 4: Further Disclosure Request

Identify what disclosure has **not** been provided but should be sought:

**Standard requests**:
- Complete criminal histories of all Crown witnesses
- All previous statements by complainant/witnesses
- Police communications (emails, texts, CAD notes) regarding the investigation
- Body-worn camera footage of attending officers
- CCTV from all identified locations
- Scene photographs (all, not just selected)
- Exhibit handling and storage records
- Expert report working papers and methodology
- 111/emergency call recordings
- Cell site data and extraction reports
- Social media/message extractions (full, not summaries)

**Case-specific requests**: Tailor to the disclosed allegations.

---

## Part 5: Bail Analysis

- **Current conditions**: List all current bail conditions
- **Principles**: Bail Act 2000 - s 7 (right to bail unless justified grounds),
s 8 (grounds for remand in custody), s 14 (bail conditions may only be imposed
if justified)
- **Assessment of each condition**: Is it justified? Is it the least restrictive?
- **Proposed less restrictive alternatives**: For each condition that appears
excessive, propose alternatives
- **Variation strategy**: Recommended approach to seeking variation
- **EM bail**: Consider electronic monitoring as alternative to remand or
curfew conditions

---

## Part 6: Accused's Options

Set out all available paths with pros/cons:

1. **Elect trial by jury** (if Category 3 or 4 offence)
2. **Plead not guilty** - trial pathway
3. **Plead guilty** - sentencing pathway, maximum credit available
4. **Diversion** (if eligible) - Police or court diversion programmes
5. **Discharge without conviction** (s 106 Sentencing Act 2002)
6. **Hybrid approach** - plead to lesser/chosen charges, contest others
7. **Pre-trial applications** - stay, exclusion, or severance
8. **Negotiation with Crown** - resolution discussions

For each option: likelihood, advantages, disadvantages, and likely outcome.

---

## Part 7: Risk Assessment

- **Overall case strength**: Crown case assessment (strong/moderate/weak)
- **Defence strengths**: Key favourable factors
- **Defence weaknesses**: Key vulnerabilities
- **Critical evidence**: Evidence that will likely determine the outcome
- **Witness reliability issues**: Credibility concerns for Crown witnesses
- **Sentencing exposure**: If convicted, realistic sentencing range
- **Appellate prospects**: If convicted, grounds for appeal

---

## Part 8: Disclaimer

Every analysis must conclude with:

> **IMPORTANT NOTICE**: This analysis is generated by an artificial intelligence
> system acting as a co-counsel research and analysis tool. It is **not legal
> advice**. All information generated must be independently evaluated by the
> instructing qualified legal practitioner. The instructing practitioner must
> form their own independent legal advice based on their professional judgment,
> the complete circumstances of the case, and all relevant legal authorities.
> This tool does not have access to all potentially relevant materials and
cannot account for facts and circumstances not disclosed in the provided
documents. Reliance on this analysis without independent professional
assessment is not recommended.
