# NZ Legal Sources Reference

Overview of the three source repositories integrated into the analysis system.

---

## Source 1: NZ Legislation (Criminal Law)

Primary statutes relevant to criminal defence analysis. The local legislation
folder contains the full text of these and other relevant Acts.

### Core Criminal Statutes
- **Crimes Act 1961** - Substantive criminal offences and defences (Parts 1-10)
- **Summary Offences Act 1981** - Minor criminal and public order offences
- **Criminal Procedure Act 2011** - Criminal procedure rules, charging,
  case management, trial process
- **Evidence Act 2006** - Rules of evidence, admissibility, privilege,
  witness competence, expert evidence
- **Sentencing Act 2002** - Sentencing principles, purposes, and available dispositions
- **Bail Act 2000** - Bail entitlements, grounds for remand, conditions
- **Criminal Disclosure Act 2008** - Crown disclosure obligations
- **Search and Surveillance Act 2012** - Search powers, warrants, surveillance,
  device searches
- **New Zealand Bill of Rights Act 1990** - Fundamental rights and freedoms,
  limits on state power

### Supplementary Statutes
- **Arms Act 1983** - Firearms and weapons offences
- **Misuse of Drugs Act 1975** - Drug-related offences and classifications
- **Land Transport Act 1998** - Driving and traffic offences
- **Domestic Violence Act 1995** - Protection orders and related criminal provisions
- **Harassment Act 1997** - Criminal harassment
- **Financial Markets Conduct Act 2013** - Financial crimes
- **Secret Commissions Act 1910** - Corruption and bribery

### Treaty and International
- **Te Tiriti o Waitangi / Treaty of Waitangi** - Relevant to Maori accused
  and cultural considerations in sentencing
- **International Covenant on Civil and Political Rights** - Incorporated
  through NZBORA interpretation

---

## Source 2: Case Law (Landmark Judgements)

Repository of 60-80 written judgements establishing judicial tone and hierarchy.

### Hierarchical Value
1. **Supreme Court of New Zealand** decisions - binding on all lower courts
2. **Court of Appeal** decisions - persuasive at Supreme Court, binding below
3. **High Court** decisions - persuasive at appellate level, binding in
   subsequent High Court
4. **District Court** decisions - persuasive only

### Key Categories in Repository
- **Evidential rulings**: Admissibility, expert evidence, complainant evidence
- **Procedural fairness**: Disclosure failures, trial unfairness, stays
- **Bill of Rights**: Search and seizure, arrest, detention, interview rights
- **Defence principles**: Self-defence, intoxication, mental impairment
- **Sentencing guidelines**: Starting points, discounts, totality principle
- **Bail jurisprudence**: Risk assessment, condition justification
- **Police powers**: Warrant validity, scope of search, identification

### Citation Format
Use neutral citations where available: `[Year] NZSC #`, `[Year] NZCA #`,
`[Year] NZHC #`. Include para numbers for precise reference.

---

## Source 3: NZ Police Manual

The New Zealand Police Manual contains all instructions and guidance in
chapters for administrative and operational aspects of policing.

### Relevant Chapters
- **Adult Investigation Interviewing** - Interviewer obligations, PEACE model,
  recording requirements, caution administration
- **Arrest and Detention** - Arrest powers, necessity test, custody management,
  time limits
- **Search and Surveillance** - Warrant applications, execution protocols,
  warrantless search thresholds, digital evidence
- **Family Violence** - Attendance protocols, risk assessment, powers of entry
- **Dealing with Young People** - Youth justice procedures, Oranga Tamariki
  notification, special protections
- **Evidence and Exhibits** - Chain of custody, labelling, storage, exhibit
  management systems
- **Informants and Covert Operations** - Source handling, controlled operations,
  authorisation requirements
- **Prosecution** - Charging decisions, file preparation, disclosure obligations
- **Use of Force** - Tactical options model, reporting, justification
- **Traffic and Road Policing** - Breath testing, blood specimens, serious
crash investigation
- **Bail** - Police bail decisions, bail checks, breach management

### Compliance Standard
Police are expected to comply with their own manual. Non-compliance may
not be unlawful but can support:
- Reliability challenges to evidence
- NZBORA breach arguments
- Professional standards complaints
- Sentencing credit applications
- Judicial notice of systemic issues
