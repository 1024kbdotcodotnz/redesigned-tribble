# Output Structure and Style Contract

Document structure and formatting rules for generated legal analysis reports.

---

## Document Structure

### Cover Page
- Document title: "LEGAL ANALYSIS - [Accused Name]"
- Subtitle: "Criminal Disclosure Analysis"
- Date of analysis
- Reference to source disclosure documents reviewed
- Disclaimer notice (prominent)

### Table of Contents
- Auto-generated, hyperlinked where format supports

### Section 1: Executive Summary
- 1-2 page overview for the instructing solicitor
- Key findings and recommendations in priority order
- Critical deadlines or time-sensitive actions flagged
- Overall case assessment (strength indicator)

### Section 2: Disclosure Overview
- List of all documents reviewed
- Disclosure completeness assessment
- Noted gaps in disclosure

### Section 3: Charge Analysis
- Each charge as a separate sub-section
- Elements table for each charge
- Evidential sufficiency rating
- Available defences
- Maximum penalty and sentencing range

### Section 4: Summary of Facts Review
- Timeline (tabular, date-time-Event format)
- Identified inconsistencies (cross-reference table)
- Procedural errors and omissions

### Section 5: Police Conduct Assessment
- NZBORA breach analysis (right-by-right table)
- Procedural breach identification
- Statement inconsistency matrix
- Warrant/search power compliance

### Section 6: Further Disclosure Required
- Itemised list with justification for each request
- Template request letter (optional, if requested)

### Section 7: Bail Analysis
- Current conditions table
- Assessment and recommendations
- Less restrictive alternatives proposed

### Section 8: Options and Recommendations
- All available paths with pros/cons tables
- Recommended strategy with reasoning
- Risk assessment summary

### Section 9: Expert Consensus and Divergence
- Summary of where the three experts agree
- Areas of divergence and tactical implications
- Synthesised recommendation

### Section 10: Disclaimer
- Full disclaimer notice (mandatory)
- Limitations of the analysis

---

## Style Contract

### Typography
- **Body text**: Serif font (Liberation Serif, Calibri, or equivalent),
  11-12pt, 1.15 line spacing
- **Headings**: Sans-serif font (Liberation Sans, Calibri, or equivalent)
  - Heading 1: 16pt, bold
  - Heading 2: 14pt, bold
  - Heading 3: 12pt, bold
- **Tables**: 10pt, single-spacing within cells, header row bold with
  light grey background
- **Block quotes**: 10pt, indented, italic for statutory text and case extracts
- **Legislation citations**: Italic for Act names, plain for section numbers

### Colour Palette
- **Primary text**: Black (#000000)
- **Headings**: Dark navy (#1B3A5C) for section headings
- **Accent**: Dark teal (#1E6B6B) for sub-headings and table headers
- **Highlights**: Amber (#F0A030) for critical deadlines or warnings
- **Tables**: Light grey header (#E8E8E8), white alternating rows

### Layout
- A4 page size
- Margins: 2.5cm all sides
- Paragraph spacing: 6pt after each paragraph
- Justified body text
- Page breaks before each major section (Heading 1)
- Tables span full text width where practical
- Numbered paragraphs for cross-referencing in complex sections

### Tables
- All tables have header rows with grey background and bold text
- Thin borders (0.5pt, grey #CCCCCC)
- Adequate cell padding (3pt)
- Tables must handle variable text length without clipping
- Multi-row cells allowed for commentary

### Page Elements
- Header: Document title (left), page number (right)
- Footer: Disclaimer reminder ("NOT LEGAL ADVICE - CO-COUNSEL ANALYSIS ONLY")
- No decorative graphics or imagery
- Clean, professional legal document appearance

---

## Cross-Reference System

- Sections numbered sequentially (1, 2, 3...)
- Sub-sections use decimal notation (3.1, 3.2, 3.2.1)
- Tables numbered by section (Table 3-1, Table 3-2)
- Legislation cited in full on first use, abbreviated thereafter
- Case citations use neutral citation format with para references
- Internal cross-references hyperlinked where format supports

---

## Font Handling for Mixed Content

The primary language is English. Legal documents may contain:
- Maori terms and concepts (tikanga, whanau, etc.)
- Latin legal phrases (actus reus, mens rea, inter alia)

Use a Unicode-compliant serif font that supports:
- Latin Extended characters (for Maori macrons: a, e, i, o, u)
- Standard Latin text
- Mathematical symbols (for sentencing calculations if needed)

Preferred font stack: Liberation Serif / Noto Serif / Calibri with
fallback to system serif.
